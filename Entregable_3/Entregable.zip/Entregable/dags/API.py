import requests
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
import psycopg2
import json
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from sqlalchemy import create_engine
import os


#dag_path = "D:\Entregable"    
#os.getcwd() 

#url="data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws"
#with open(dag_path+'/keys/'+"db.txt",'r') as f:
#    data_base= f.read()
#with open(dag_path+'/keys/'+"user.txt",'r') as f:
#    user= f.read()
#with open(dag_path+'/keys/'+"pwd.txt",'r') as f:
#    pwd= f.read()


#redshift_conn = {
#    'host': url,
#    'username': user,
#    'database': data_base,
#    'port': '5439',
#    'pwd': pwd
#}


default_args={
    'owner': 'Pablo',
    'start_date': datetime(2023,8,21),
    'retries': 2,
    'retry_delay': timedelta(minutes=3)
}

API_DAG_LOAD=DAG(
    dag_id='API_LOAD',
    default_args=default_args,
    description= 'descargar datos de api',
    schedule_interval=None,
    catchup=False
)


def main_request(url, endpoint):
    response = requests.get(url + endpoint)
    return response.json()

def get_pages(response):
    return response['meta']['per_page']


def parse_json_games(response):
    gameslist = []
    for e in response['data']:
        char = {
            'id': e['id'],
            'date': e['date'],
            'home_team_score': e['home_team_score'],
            'visitor_team_score': e['visitor_team_score'],
            'season': e['season'],
            'period': e['period'],
            'status': e['status'],
            'home_team_id': e['home_team']['id'],
            'visitor_team_id': e['visitor_team']['id']
        }
        gameslist.append(char)
    return gameslist


def parse_json_home_team(response):
    home_team_list = []
    for e in response['data']:
        char = {
            'id': e['home_team']['id'],
            'abbreviation': e['home_team']['abbreviation'],
            'city': e['home_team']['city'],
            'conference': e['home_team']['conference'],
            'division': e['home_team']['division'],
            'full_name': e['home_team']['full_name'],
            'name': e['home_team']['name']
        }
        home_team_list.append(char)
    return home_team_list


def parse_json_visitor_team(response):
    visitor_team_list = []
    for e in response['data']:
        char = {
            'id': e['visitor_team']['id'],
            'abbreviation': e['visitor_team']['abbreviation'],
            'city': e['visitor_team']['city'],
            'conference': e['visitor_team']['conference'],
            'division': e['visitor_team']['division'],
            'full_name': e['visitor_team']['full_name'],
            'name': e['visitor_team']['name']
        }
        visitor_team_list.append(char)
    return visitor_team_list

from sqlalchemy import create_engine
def load_data():
    url = 'https://www.balldontlie.io/api/v1/'
    endpoint = 'games'
    data = main_request(url, endpoint)
    return data

data = load_data()
df_games = pd.DataFrame(parse_json_games(data))
df_home_team = pd.DataFrame(parse_json_home_team(data))
df_visitor_team = pd.DataFrame(parse_json_visitor_team(data))

def insert_data():
    conn = create_engine('postgresql://pagustinamato_coderhouse:7kxDU66Urk@data-engineer-cluster.cyhh5bfevlmn.us-east-1.redshift.amazonaws.com:5439/data-engineer-database')
    df_games.to_sql('games_nba', conn, index=False, schema='pagustinamato_coderhouse', if_exists='replace', method=None)
    df_home_team.to_sql('home_teams_nba', conn, index=False, schema='pagustinamato_coderhouse', if_exists='replace',method=None)
    df_visitor_team.to_sql('visitors_teams_nba', conn, index=False, schema='pagustinamato_coderhouse',if_exists='replace',method=None)

#load data
task_62= PythonOperator(
        task_id='load',
        python_callable=load_data,
        dag=API_DAG_LOAD,
)

#insert data
task_72= PythonOperator(
        task_id='insert',
        python_callable=insert_data,
        dag=API_DAG_LOAD,
)

# Definicion orden de tareas
task_62 >> task_72
