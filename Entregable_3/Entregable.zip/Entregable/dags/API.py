import requests
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path
import psycopg2
import json
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from sqlalchemy import create_engine
import os
from Entregable_1 import LOAD_API_DATA


default_args={
    'owner': 'Pablo',
    'start_date': datetime(2023,8,21),
    'retries': 2,
    'retry_delay': timedelta(minutes=3)
}

API_DAG_LOAD=DAG(
    dag_id='API_LOAD_V2',
    default_args=default_args,
    description= 'descargar datos de api',
    schedule_interval="@daily",
    catchup=False
)

#load data
task_62= PythonOperator(
        task_id='load',
        python_callable=LOAD_API_DATA,
        dag=API_DAG_LOAD,
)


# Definicion orden de tareas
task_62
