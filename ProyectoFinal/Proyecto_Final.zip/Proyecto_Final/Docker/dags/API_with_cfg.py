from email import message
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.email_operator import EmailOperator
import os
from Entregable_1 import LOAD_API_DATA


default_args={
    'owner': 'Pablo',
    'start_date': datetime(2023,8,21),
    'retries': 2,
    'retry_delay': timedelta(minutes=3)
}

API_DAG_LOAD=DAG(
    dag_id='API_LOAD_V2',
    default_args=default_args,
    description= 'descargar datos de api',
    schedule_interval='@daily',
    catchup=False
)

#Ejecuta .py
task_1 = PythonOperator(
        task_id='Execute',
        python_callable=LOAD_API_DATA,
        dag=API_DAG_LOAD,
)

#manda email
task_2 = EmailOperator(
        task_id='send_email',
        to='pagustinamato@gmail.com',
        subject='Airflow Alert',
        html_content="""<h3>Email Airflow Alert</h3>""",
        dag=API_DAG_LOAD
)

# Definicion orden de tareas
task_1 >> task_2